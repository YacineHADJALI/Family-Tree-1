/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import TreeView from './components/TreeView';
import PersonDetailModal from './components/PersonDetailModal';
import TimelineView from './components/TimelineView';
import AnalyticsView from './components/AnalyticsView';
import { FamilyTreeData, Person, Marriage } from './types';
import { STANDARD_BAKER_TREE } from './preloadedTrees';

// Helper to determine the best initial focus member depending on the tree loaded
const getBestInitialFocus = (tree: FamilyTreeData): Person | null => {
  if (tree.people.length === 0) return null;
  const preferredIds = ['parent_m', 'homer', 'henry8', 'zeus'];
  for (const pid of preferredIds) {
    const match = tree.people.find(p => p.id === pid);
    if (match) return match;
  }
  return tree.people[0];
};

export default function App() {
  const [treeData, setTreeData] = useState<FamilyTreeData>(() => {
    try {
      const saved = localStorage.getItem('family_tree_current');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Failed to restore family tree from LocalStorage:', e);
    }
    return STANDARD_BAKER_TREE;
  });

  const [activePerson, setActivePerson] = useState<Person | null>(() => {
    return getBestInitialFocus(treeData);
  });

  const [activeTab, setActiveTab] = useState<'tree' | 'timeline' | 'analytics'>('tree');
  
  // Modal controllers
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPerson, setEditingPerson] = useState<Person | null>(null);
  const [quickRelation, setQuickRelation] = useState<{
    relatedToId: string;
    role: 'father' | 'mother' | 'spouse' | 'child';
  } | undefined>(undefined);

  // Auto-sync treeData to LocalStorage when changed
  useEffect(() => {
    localStorage.setItem('family_tree_current', JSON.stringify(treeData));
  }, [treeData]);

  // Adjust active screen state if active Person was unlinked/modified
  useEffect(() => {
    if (activePerson) {
      const refreshed = treeData.people.find(p => p.id === activePerson.id);
      if (refreshed) {
        setActivePerson(refreshed);
      } else {
        setActivePerson(getBestInitialFocus(treeData));
      }
    } else {
      setActivePerson(getBestInitialFocus(treeData));
    }
  }, [treeData, activePerson]);

  const handleSelectPerson = (person: Person) => {
    setActivePerson(person);
    // Shift view mode tab back to tree on selection
    setActiveTab('tree');
  };

  const handleSelectPersonAndToggleTab = (person: Person) => {
    setActivePerson(person);
    setActiveTab('tree');
  };

  const handleLoadPresetTree = (preset: FamilyTreeData) => {
    setTreeData(preset);
    const bestFocus = getBestInitialFocus(preset);
    setActivePerson(bestFocus);
    setActiveTab('tree');
  };

  const handleImportTree = (imported: FamilyTreeData) => {
    setTreeData(imported);
    const bestFocus = getBestInitialFocus(imported);
    setActivePerson(bestFocus);
    setActiveTab('tree');
  };

  const handleResetTree = () => {
    const freshRootPerson: Person = {
      id: 'root_draft',
      firstName: 'Draft',
      lastName: 'Member',
      gender: 'male',
      isDeceased: false,
      occupation: 'Original Root Member',
      biography: 'Begin by editing this node to shape your personal family tree.',
      avatarColor: 'bg-indigo-100 text-indigo-700 border-indigo-300'
    };

    const freshTree: FamilyTreeData = {
      name: "My Family Tree",
      description: "A freshly draft family canvas ready to build your personal lineages.",
      people: [freshRootPerson],
      marriages: []
    };

    setTreeData(freshTree);
    setActivePerson(freshRootPerson);
    setActiveTab('tree');
  };

  // Add person from bottom/sidebar buttons
  const handleAddNewFirstLevelPerson = () => {
    setEditingPerson(null);
    setQuickRelation(undefined);
    setIsModalOpen(true);
  };

  // Triggered when a user clicks on an interactive slot like 'Add Father', 'Add Mother', etc.
  const handleAddRelation = (relatedToId: string, role: 'father' | 'mother' | 'spouse' | 'child') => {
    setEditingPerson(null);
    setQuickRelation({ relatedToId, role });
    setIsModalOpen(true);
  };

  const handleEditPerson = (person: Person) => {
    setEditingPerson(person);
    setQuickRelation(undefined);
    setIsModalOpen(true);
  };

  const handleSavePerson = (savedPerson: Person) => {
    const isNew = !treeData.people.some(p => p.id === savedPerson.id);
    
    let updatedPeople = isNew 
      ? [...treeData.people, savedPerson]
      : treeData.people.map(p => p.id === savedPerson.id ? savedPerson : p);

    let updatedMarriages = [...treeData.marriages];

    // If we were creating this person as part of a relative slot connection
    if (isNew && quickRelation) {
      const targetId = quickRelation.relatedToId;
      const role = quickRelation.role;

      if (role === 'father') {
        // Find child, update their fatherId
        updatedPeople = updatedPeople.map(p => 
          p.id === targetId ? { ...p, fatherId: savedPerson.id } : p
        );
      } else if (role === 'mother') {
        // Find child, update their motherId
        updatedPeople = updatedPeople.map(p => 
          p.id === targetId ? { ...p, motherId: savedPerson.id } : p
        );
      } else if (role === 'spouse') {
        // Create dual-marriage entry
        const isDivorced = false;
        const newMarriage: Marriage = {
          id: `m_${Date.now()}`,
          person1Id: targetId,
          person2Id: savedPerson.id,
          isDivorced
        };
        updatedMarriages.push(newMarriage);
      } else if (role === 'child') {
        // Determine whether targetId is mother or father of this new child
        const parent = treeData.people.find(p => p.id === targetId);
        if (parent) {
          if (parent.gender === 'male') {
            savedPerson.fatherId = parent.id;
          } else if (parent.gender === 'female') {
            savedPerson.motherId = parent.id;
          }
          // Replace savedPerson with its updated parent links
          updatedPeople = updatedPeople.map(p => p.id === savedPerson.id ? savedPerson : p);
        }
      }
    }

    setTreeData({
      ...treeData,
      people: updatedPeople,
      marriages: updatedMarriages
    });

    setActivePerson(savedPerson);
    setIsModalOpen(false);
    setEditingPerson(null);
    setQuickRelation(undefined);
  };

  const handleRemovePerson = (id: string) => {
    // 1. Remove the person
    const remainingPeople = treeData.people.filter(p => p.id !== id)
      // 2. Unlink them as parents for any descendants
      .map(p => {
        const copy = { ...p };
        if (copy.fatherId === id) delete copy.fatherId;
        if (copy.motherId === id) delete copy.motherId;
        return copy;
      });

    // 3. Remove marriage joints
    const remainingMarriages = treeData.marriages.filter(m => 
      m.person1Id !== id && m.person2Id !== id
    );

    setTreeData({
      ...treeData,
      people: remainingPeople,
      marriages: remainingMarriages
    });

    // Focus shifts automatically in dynamic state effect
  };

  return (
    <main className="w-screen h-screen flex bg-[#0A0A0A] overflow-hidden font-sans antialiased text-[#E5E5E5]" id="family-tree-app-root">
      
      {/* Sidebar navigation and search */}
      <Sidebar
        treeData={treeData}
        activePerson={activePerson}
        onSelectPerson={handleSelectPerson}
        onAddPerson={handleAddNewFirstLevelPerson}
        onLoadTree={handleLoadPresetTree}
        onImportTree={handleImportTree}
        onResetTree={handleResetTree}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main panel - Switches content depending on activeTab */}
      <section className="flex-1 flex flex-col min-w-0" id="main-content-panel">
        {activeTab === 'tree' && (
          <TreeView
            treeData={treeData}
            activePerson={activePerson}
            onSelectPerson={handleSelectPerson}
            onEditPerson={handleEditPerson}
            onAddRelation={handleAddRelation}
            onRemovePerson={handleRemovePerson}
          />
        )}

        {activeTab === 'timeline' && (
          <TimelineView
            treeData={treeData}
            onSelectPersonAndToggleTab={handleSelectPersonAndToggleTab}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            treeData={treeData}
          />
        )}
      </section>

      {/* Detail creator / editor modal */}
      {isModalOpen && (
        <PersonDetailModal
          person={editingPerson}
          treeData={treeData}
          onSave={handleSavePerson}
          onClose={() => {
            setIsModalOpen(false);
            setEditingPerson(null);
            setQuickRelation(undefined);
          }}
          quickRelationConfig={quickRelation}
        />
      )}

    </main>
  );
}
