/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BarChart, Users, TrendingUp, Calendar, Heart, Award, MapPin, Briefcase } from 'lucide-react';
import { FamilyTreeData, Person } from '../types';

interface AnalyticsViewProps {
  treeData: FamilyTreeData;
}

export default function AnalyticsView({ treeData }: AnalyticsViewProps) {
  const { people } = treeData;

  if (people.length === 0) {
    return (
      <div className="flex-1 bg-[#0A0A0A] flex flex-col items-center justify-center p-8 text-center" id="empty-analytics">
        <Users size={36} className="text-[#C5A059]/30 mb-3" />
        <h3 className="text-[#C5A059] font-serif font-bold">No Records for Analytics yet</h3>
        <p className="text-[#666] text-xs max-w-xs mt-2 font-sans">
          Add some members to your family tree, and we will automatically compile demographics, lifespans, and geographics.
        </p>
      </div>
    );
  }

  // 1. Demographics
  const maleCount = people.filter(p => p.gender === 'male').length;
  const femaleCount = people.filter(p => p.gender === 'female').length;
  const nonbinaryCount = people.filter(p => p.gender === 'nonbinary' || p.gender === 'other').length;
  const deceasedCount = people.filter(p => p.isDeceased).length;
  const livingCount = people.length - deceasedCount;

  // 2. Lifespan Average
  let lifespanSum = 0;
  let lifespanCount = 0;
  people.forEach(p => {
    if (p.isDeceased && p.birthDate && p.deathDate) {
      try {
        const birthYr = parseInt(p.birthDate.split('-')[0]);
        const deathYr = parseInt(p.deathDate.split('-')[0]);
        if (!isNaN(birthYr) && !isNaN(deathYr)) {
          const age = deathYr - birthYr;
          if (age >= 0) {
            lifespanSum += age;
            lifespanCount++;
          }
        }
      } catch {}
    }
  });
  const avgLifespan = lifespanCount > 0 ? Math.round(lifespanSum / lifespanCount) : null;

  // 3. Top Surnames
  const surnamesMap: { [key: string]: number } = {};
  people.forEach(p => {
    const name = (p.lastName || 'Unknown').trim();
    if (name) surnamesMap[name] = (surnamesMap[name] || 0) + 1;
    if (p.maidenName && p.maidenName.trim()) {
      const mn = p.maidenName.trim();
      surnamesMap[mn] = (surnamesMap[mn] || 0) + 1;
    }
  });
  const topSurnames = Object.entries(surnamesMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  // 4. Job Sectors / Occupations
  const jobsMap: { [key: string]: number } = {};
  people.forEach(p => {
    const job = (p.occupation || '').trim();
    if (job) {
      jobsMap[job] = (jobsMap[job] || 0) + 1;
    }
  });
  const topJobs = Object.entries(jobsMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  // 5. Geographic Locations Hotspots
  const locationsMap: { [key: string]: number } = {};
  people.forEach(p => {
    const bp = p.birthPlace?.trim();
    if (bp) locationsMap[bp] = (locationsMap[bp] || 0) + 1;
    const dp = p.deathPlace?.trim();
    if (dp) locationsMap[dp] = (locationsMap[dp] || 0) + 1;
  });
  const topLocations = Object.entries(locationsMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  // 6. Lifespan age bins
  const bins = {
    '0 - 20': 0,
    '21 - 40': 0,
    '41 - 60': 0,
    '61 - 80': 0,
    '81+': 0
  };
  people.forEach(p => {
    if (p.isDeceased && p.birthDate && p.deathDate) {
      try {
        const b = parseInt(p.birthDate.split('-')[0]);
        const d = parseInt(p.deathDate.split('-')[0]);
        if (!isNaN(b) && !isNaN(d)) {
          const age = d - b;
          if (age <= 20) bins['0 - 20']++;
          else if (age <= 40) bins['21 - 40']++;
          else if (age <= 60) bins['41 - 60']++;
          else if (age <= 80) bins['61 - 80']++;
          else bins['81+']++;
        }
      } catch {}
    }
  });
  const binEntries = Object.entries(bins);
  const maxBinValue = Math.max(...binEntries.map(e => e[1]), 1);

  return (
    <div className="flex-1 overflow-y-auto bg-[#0A0A0A] p-6 sm:p-8 text-[#E5E5E5] relative" id="analytics-explorer">
      {/* Grid Overlay Dots Texture */}
      <div className="absolute inset-0 bg-grid-dots opacity-5 pointer-events-none"></div>

      <div className="max-w-5xl mx-auto space-y-6 relative z-10">
        
        {/* Dashboard Header */}
        <div className="bg-[#0D0D0D] p-5 border border-[#2A2A28]">
          <h2 className="text-base font-serif font-bold text-[#E5E5E5] flex items-center gap-2 leading-none uppercase tracking-wide">
            <BarChart size={16} className="text-[#C5A059]" /> Demographics & Archives Analytics
          </h2>
          <p className="text-[11px] text-[#888] mt-1 font-sans">Real-time statistics regarding lifespans, geographic centers, and generational roles of {treeData.name}.</p>
        </div>

        {/* Core metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4" id="stats-numerical-row">
          <div className="bg-[#0D0D0D] p-5 border border-[#2A2A28] flex items-center justify-between">
            <div>
              <span className="text-[9px] text-[#666] font-bold uppercase block tracking-widest font-mono">Total Members</span>
              <span className="text-xl font-serif font-bold text-[#C5A059] mt-1.5 block">{people.length}</span>
            </div>
            <span className="p-2.5 bg-[#161616] text-[#C5A059] border border-[#2A2A28]"><Users size={15} /></span>
          </div>

          <div className="bg-[#0D0D0D] p-5 border border-[#2A2A28] flex items-center justify-between">
            <div>
              <span className="text-[9px] text-[#666] font-bold uppercase block tracking-widest font-mono">Average Lifespan</span>
              <span className="text-xl font-serif font-bold text-[#C5A059] mt-1.5 block">
                {avgLifespan !== null ? `${avgLifespan} yrs` : 'N/A'}
              </span>
            </div>
            <span className="p-2.5 bg-[#161616] text-[#C5A059] border border-[#2A2A28]"><TrendingUp size={15} /></span>
          </div>

          <div className="bg-[#0D0D0D] p-5 border border-[#2A2A28] flex items-center justify-between">
            <div>
              <span className="text-[9px] text-[#666] font-bold uppercase block tracking-widest font-mono">Living Descendants</span>
              <span className="text-xl font-serif font-bold text-[#EADAC2] mt-1.5 block">{livingCount}</span>
            </div>
            <span className="p-2.5 bg-[#161616] text-[#EADAC2] border border-[#2A2A28]"><Heart size={15} /></span>
          </div>

          <div className="bg-[#0D0D0D] p-5 border border-[#2A2A28] flex items-center justify-between">
            <div>
              <span className="text-[9px] text-[#666] font-bold uppercase block tracking-widest font-mono">Archived Ancestors</span>
              <span className="text-xl font-serif font-bold text-[#888] mt-1.5 block">{deceasedCount}</span>
            </div>
            <span className="p-2.5 bg-[#161616] text-[#888] border border-[#2A2A28]"><Calendar size={15} /></span>
          </div>
        </div>

        {/* Visual Charts Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5" id="charts-visual-row">
          
          {/* Card 1: Custom Donut Sector Ring representing Gender Breakdown with elegant earthy gold colours */}
          <div className="bg-[#0D0D0D] p-5 border border-[#2A2A28] space-y-4">
            <div>
              <h3 className="text-xs font-serif font-bold tracking-wide text-[#C5A059] uppercase">Gender Distribution Profile</h3>
              <p className="text-[10px] text-[#666] font-sans">Meticulous proportions of recorded gender identities in lineage.</p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-around gap-4" style={{ contentVisibility: 'auto' }}>
              {/* Custom SVG Ring in luxury shades */}
              <div className="relative w-28 h-28 flex items-center justify-center shrink-0">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  {/* Empty base track circle */}
                  <circle cx="50" cy="50" r="40" fill="none" stroke="#161616" strokeWidth="10" />
                  
                  {(() => {
                    const total = Math.max(people.length, 1);
                    const pMale = (maleCount / total) * 100;
                    const pFemale = (femaleCount / total) * 100;
                    const pNon = (nonbinaryCount / total) * 100;
                    
                    const r = 40;
                    const circumference = 2 * Math.PI * r;
                    
                    const dashMale = (pMale / 100) * circumference;
                    const dashFemale = (pFemale / 100) * circumference;
                    const dashNon = (pNon / 100) * circumference;
                    
                    const offsetMale = 0;
                    const offsetFemale = dashMale;
                    const offsetNon = dashMale + dashFemale;

                    return (
                      <>
                        {/* Male Sector: Classic Gold */}
                        {dashMale > 0 && (
                          <circle
                            cx="50"
                            cy="50"
                            r={r}
                            fill="none"
                            stroke="#C5A059"
                            strokeWidth="10"
                            strokeDasharray={`${dashMale} ${circumference - dashMale}`}
                            strokeDashoffset={-offsetMale}
                            className="transition-all duration-500"
                          />
                        )}
                        {/* Female Sector: Light Alabaster Cream */}
                        {dashFemale > 0 && (
                          <circle
                            cx="50"
                            cy="50"
                            r={r}
                            fill="none"
                            stroke="#EADAC2"
                            strokeWidth="10"
                            strokeDasharray={`${dashFemale} ${circumference - dashFemale}`}
                            strokeDashoffset={-offsetFemale}
                            className="transition-all duration-500"
                          />
                        )}
                        {/* Other Sector: Antique Bronze */}
                        {dashNon > 0 && (
                          <circle
                            cx="50"
                            cy="50"
                            r={r}
                            fill="none"
                            stroke="#755928"
                            strokeWidth="10"
                            strokeDasharray={`${dashNon} ${circumference - dashNon}`}
                            strokeDashoffset={-offsetNon}
                            className="transition-all duration-500"
                          />
                        )}
                      </>
                    );
                  })()}
                </svg>
                {/* Center title count */}
                <div className="absolute flex flex-col items-center">
                  <span className="text-lg font-serif font-bold text-[#E5E5E5] leading-none">{people.length}</span>
                  <span className="text-[9px] text-[#666] uppercase tracking-widest font-mono">Total</span>
                </div>
              </div>

              {/* Legend checklist */}
              <div className="space-y-2.5 text-[10px] uppercase tracking-wider font-mono text-[#888] w-full sm:max-w-[150px]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-none bg-[#C5A059]"></span>
                    <span>Male</span>
                  </div>
                  <span className="text-[#C5A059] font-bold">{maleCount}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-none bg-[#EADAC2]"></span>
                    <span>Female</span>
                  </div>
                  <span className="text-[#EADAC2] font-bold">{femaleCount}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-none bg-[#755928]"></span>
                    <span>Other</span>
                  </div>
                  <span className="text-[#755928] font-bold">{nonbinaryCount}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Card 2: Custom Horizontal Bar list showing Hist Lifespan Ranges */}
          <div className="bg-[#0D0D0D] p-5 border border-[#2A2A28] space-y-4">
            <div>
              <h3 className="text-xs font-serif font-bold tracking-wide text-[#C5A059] uppercase">Age At Demise Profile (Deceased)</h3>
              <p className="text-[10px] text-[#666] font-sans">Historical lifespan distributions grouped into generational bounds.</p>
            </div>

            {deceasedCount === 0 || lifespanCount === 0 ? (
              <div className="py-6 text-center text-[#555] text-xs font-serif italic">
                No deceased ancestors with complete life dates recorded.
              </div>
            ) : (
              <div className="space-y-3 text-[10px] font-mono uppercase tracking-wider" style={{ contentVisibility: 'auto' }}>
                {binEntries.map(([label, count]) => {
                  const pct = Math.round((count / maxBinValue) * 100);
                  return (
                    <div key={label} className="grid grid-cols-6 items-center gap-2">
                      <span className="text-[#666] font-semibold text-right pr-2 col-span-1">{label}</span>
                      <div className="col-span-4 bg-[#161616] rounded-none h-2 border border-[#222]">
                        <div 
                          className="bg-[#C5A059] h-full transition-all duration-500" 
                          style={{ width: `${pct}%` }}
                        ></div>
                      </div>
                      <span className="col-span-1 text-[#AAA] font-bold pl-2">{count}</span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>

        {/* Surnames & Hotspots breakdown row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5" id="breakdowns-row">
          
          {/* Card A: Top Surnames Scorecard */}
          <div className="bg-[#0D0D0D] p-5 border border-[#2A2A28] flex flex-col justify-between" style={{ contentVisibility: 'auto' }}>
            <div className="mb-4">
              <h3 className="text-xs font-serif font-bold text-[#C5A059] flex items-center gap-2 uppercase tracking-wide">
                <Award size={14} className="text-[#C5A059]" /> Recorded Surnames
              </h3>
              <p className="text-[10px] text-[#666] font-sans">Major lineage branches and recurring noble family names.</p>
            </div>

            <div className="space-y-4">
              {topSurnames.length === 0 ? (
                <p className="text-xs text-[#555] text-center py-6 italic font-serif">No surnames recorded.</p>
              ) : (
                topSurnames.map(([name, count], idx) => {
                  const pct = Math.round((count / people.length) * 100);
                  return (
                    <div key={name} className="space-y-1">
                      <div className="flex justify-between text-[11px] font-serif font-bold text-[#E5E5E5]">
                        <span className="tracking-wide">{idx + 1}. {name}</span>
                        <span className="font-mono text-[#C5A059]">{count} profiles</span>
                      </div>
                      <div className="w-full bg-[#161616] h-1 border border-[#222]">
                        <div className="bg-[#C5A059] h-full" style={{ width: `${pct}%` }}></div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Card B: Occupations Summary */}
          <div className="bg-[#0D0D0D] p-5 border border-[#2A2A28] flex flex-col justify-between" style={{ contentVisibility: 'auto' }}>
            <div className="mb-4">
              <h3 className="text-xs font-serif font-bold text-[#C5A059] flex items-center gap-2 uppercase tracking-wide">
                <Briefcase size={14} className="text-[#C5A059]" /> Occupations & Roles
              </h3>
              <p className="text-[10px] text-[#666] font-sans font-medium">Top logged careers and societal duties inside profiles.</p>
            </div>

            <div className="space-y-4">
              {topJobs.length === 0 ? (
                <p className="text-xs text-[#555] text-center py-6 italic font-serif">No occupations logged inside record cards.</p>
              ) : (
                topJobs.map(([job, count], idx) => {
                  const maxCount = Math.max(...topJobs.map(j => j[1]));
                  const pct = Math.round((count / maxCount) * 100);
                  return (
                    <div key={job} className="space-y-1">
                      <div className="flex justify-between text-[11px] font-serif font-bold text-[#E5E5E5]">
                        <span className="truncate max-w-[150px] tracking-wide">{idx+1}. {job}</span>
                        <span className="font-mono text-[#EADAC2]">{count}</span>
                      </div>
                      <div className="w-full bg-[#161616] h-1 border border-[#222]">
                        <div className="bg-[#EADAC2] h-full" style={{ width: `${pct}%` }}></div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Card C: Geography Locations */}
          <div className="bg-[#0D0D0D] p-5 border border-[#2A2A28] flex flex-col justify-between" style={{ contentVisibility: 'auto' }}>
            <div className="mb-4">
              <h3 className="text-xs font-serif font-bold text-[#C5A059] flex items-center gap-2 uppercase tracking-wide">
                <MapPin size={14} className="text-[#C5A059]" /> Archival Geography
              </h3>
              <p className="text-[10px] text-[#666] font-sans">Most recurrent historic homeland registry points mapped.</p>
            </div>

            <div className="space-y-4">
              {topLocations.length === 0 ? (
                <p className="text-xs text-[#555] text-center py-6 italic font-serif">No historic birthplace locations logged.</p>
              ) : (
                topLocations.map(([loc, count], idx) => {
                  const maxCount = Math.max(...topLocations.map(l => l[1]));
                  const pct = Math.round((count / maxCount) * 100);
                  return (
                    <div key={loc} className="space-y-1">
                      <div className="flex justify-between text-[11px] font-serif font-bold text-[#E5E5E5]">
                        <span className="truncate max-w-[150px] tracking-wide" title={loc}>{idx+1}. {loc}</span>
                        <span className="font-mono text-[#755928] font-bold">{count}</span>
                      </div>
                      <div className="w-full bg-[#161616] h-1 border border-[#222]">
                        <div className="bg-[#755928] h-full" style={{ width: `${pct}%` }}></div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
