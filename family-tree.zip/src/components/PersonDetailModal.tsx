/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { X, Save, ShieldAlert, Heart, RefreshCw, Layers } from 'lucide-react';
import { Person, Gender, FamilyTreeData } from '../types';

interface PersonDetailModalProps {
  person: Person | null; // Null if creating blank new
  treeData: FamilyTreeData;
  onSave: (person: Person) => void;
  onClose: () => void;
  quickRelationConfig?: {
    relatedToId: string;
    role: 'father' | 'mother' | 'spouse' | 'child';
  };
}

const AVATAR_BG_COLORS = [
  'bg-blue-950/40 text-blue-300 border-blue-900/40',
  'bg-rose-950/40 text-rose-300 border-rose-900/40',
  'bg-purple-950/40 text-purple-300 border-purple-900/40',
  'bg-emerald-950/40 text-emerald-300 border-emerald-900/40',
  'bg-yellow-950/40 text-yellow-300 border-yellow-900/40',
  'bg-amber-950/40 text-[#C5A059] border-[#A37F3E]/40',
  'bg-stone-900/60 text-stone-300 border-stone-800',
  'bg-red-950/40 text-red-300 border-red-900/40',
  'bg-indigo-950/40 text-indigo-300 border-indigo-900/40',
  'bg-neutral-900 text-neutral-300 border-neutral-700',
];

export default function PersonDetailModal({
  person,
  treeData,
  onSave,
  onClose,
  quickRelationConfig
}: PersonDetailModalProps) {
  // Local states for inputs
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [maidenName, setMaidenName] = useState('');
  const [nickname, setNickname] = useState('');
  const [suffix, setSuffix] = useState('');
  const [gender, setGender] = useState<Gender>('male');
  const [isDeceased, setIsDeceased] = useState(false);
  const [birthDate, setBirthDate] = useState('');
  const [birthPlace, setBirthPlace] = useState('');
  const [deathDate, setDeathDate] = useState('');
  const [deathPlace, setDeathPlace] = useState('');
  const [occupation, setOccupation] = useState('');
  const [biography, setBiography] = useState('');
  const [avatarColor, setAvatarColor] = useState(AVATAR_BG_COLORS[0]);
  
  // Relations mappings
  const [fatherId, setFatherId] = useState('');
  const [motherId, setMotherId] = useState('');

  // Initializing state based on selected person or relation
  useEffect(() => {
    if (person) {
      setFirstName(person.firstName || '');
      setLastName(person.lastName || '');
      setMaidenName(person.maidenName || '');
      setNickname(person.nickname || '');
      setSuffix(person.suffix || '');
      setGender(person.gender || 'male');
      setIsDeceased(person.isDeceased || false);
      setBirthDate(person.birthDate || '');
      setBirthPlace(person.birthPlace || '');
      setDeathDate(person.deathDate || '');
      setDeathPlace(person.deathPlace || '');
      setOccupation(person.occupation || '');
      setBiography(person.biography || '');
      setAvatarColor(person.avatarColor || AVATAR_BG_COLORS[0]);
      setFatherId(person.fatherId || '');
      setMotherId(person.motherId || '');
    } else {
      // Empty creation setup
      setFirstName('');
      setLastName('');
      setMaidenName('');
      setNickname('');
      setSuffix('');
      setGender('male');
      setIsDeceased(false);
      setBirthDate('');
      setBirthPlace('');
      setDeathDate('');
      setDeathPlace('');
      setOccupation('');
      setBiography('');
      setFatherId('');
      setMotherId('');
      
      // Auto assign customized presets if added via connection slot
      if (quickRelationConfig) {
        const parent = treeData.people.find(p => p.id === quickRelationConfig.relatedToId);
        
        if (quickRelationConfig.role === 'father') {
          setGender('male');
          if (parent) setLastName(parent.lastName);
        } else if (quickRelationConfig.role === 'mother') {
          setGender('female');
        } else if (quickRelationConfig.role === 'spouse') {
          if (parent) {
            setGender(parent.gender === 'male' ? 'female' : 'male');
            setLastName(parent.lastName);
          }
        } else if (quickRelationConfig.role === 'child') {
          if (parent) {
            setLastName(parent.lastName);
            if (parent.gender === 'male') {
              setFatherId(parent.id);
            } else if (parent.gender === 'female') {
              setMotherId(parent.id);
            }
          }
        }
      }
      
      const randColor = AVATAR_BG_COLORS[Math.floor(Math.random() * AVATAR_BG_COLORS.length)];
      setAvatarColor(randColor);
    }
  }, [person, quickRelationConfig, treeData]);

  // Handle saving
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim()) {
      alert("First name is required to register a member.");
      return;
    }

    const savedPerson: Person = {
      id: person?.id || `p_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      maidenName: maidenName.trim() || undefined,
      nickname: nickname.trim() || undefined,
      suffix: suffix.trim() || undefined,
      gender,
      isDeceased,
      birthDate: birthDate || undefined,
      birthPlace: birthPlace.trim() || undefined,
      deathDate: isDeceased ? (deathDate || undefined) : undefined,
      deathPlace: isDeceased ? (deathPlace.trim() || undefined) : undefined,
      occupation: occupation.trim() || undefined,
      biography: biography.trim() || undefined,
      avatarColor,
      fatherId: fatherId || undefined,
      motherId: motherId || undefined,
    };

    onSave(savedPerson);
  };

  // Prevent parent loops
  const potentialFathers = treeData.people.filter(p => p.id !== person?.id && p.gender === 'male');
  const potentialMothers = treeData.people.filter(p => p.id !== person?.id && p.gender === 'female');

  return (
    <div className="fixed inset-0 bg-black/85 flex items-center justify-center p-4 z-50 backdrop-blur-xs overflow-y-auto" id="person-detail-modal">
      <div className="bg-[#0D0D0D] rounded-none w-full max-w-2xl shadow-none border border-[#2A2A28] flex flex-col max-h-[90vh]" style={{ contentVisibility: 'auto' }}>
        
        {/* Modal Header */}
        <div className="p-5 border-b border-[#2A2A28] flex items-center justify-between bg-[#0A0A0A] shrink-0">
          <div>
            <h3 className="text-sm font-serif font-bold tracking-wider text-[#C5A059] uppercase" id="modal-heading-title">
              {person ? `Adjust Archival Profile: ${person.firstName} ${person.lastName}` : 'Registry New Lineage Member'}
            </h3>
            <p className="text-[10px] text-[#666] font-mono uppercase tracking-widest mt-1">
              {quickRelationConfig 
                ? `Forging connection as ${quickRelationConfig.role} of ${treeData.people.find(p => p.id === quickRelationConfig.relatedToId)?.firstName}`
                : 'Define core demographics, biological lineages, and lifecycle history.'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-[#1E1E1E] text-[#666] hover:text-[#C5A059] transition-colors cursor-pointer"
            id="close-modal-btn"
          >
            <X size={16} />
          </button>
        </div>

        {/* Modal Form Submission Area */}
        <form onSubmit={handleFormSubmit} className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-thin" id="member-editor-form">
          
          {/* Section 1: Demographics */}
          <div className="space-y-4">
            <h4 className="text-[10px] uppercase tracking-widest text-[#C5A059] border-b border-[#2A2A28] pb-1.5 flex items-center gap-1.5 font-mono">
              <Layers size={12} className="text-[#C5A059]" /> Demographics
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
              <div className="col-span-2">
                <label className="block text-[#666] text-[9px] font-mono uppercase tracking-wider mb-1.5">First Name <span className="text-[#C5A059]">*</span></label>
                <input
                  id="input-first-name"
                  type="text"
                  required
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#161616] border border-[#2A2A28] text-xs text-[#E5E5E5] placeholder-[#444] rounded-none focus:outline-none focus:border-[#C5A059] transition-colors"
                  placeholder="First name eg. Arthur"
                />
              </div>

              <div>
                <label className="block text-[#666] text-[9px] font-mono uppercase tracking-wider mb-1.5">Last Name</label>
                <input
                  id="input-last-name"
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#161616] border border-[#2A2A28] text-xs text-[#E5E5E5] placeholder-[#444] rounded-none focus:outline-none focus:border-[#C5A059] transition-colors"
                  placeholder="Smith"
                />
              </div>

              <div>
                <label className="block text-[#666] text-[9px] font-mono uppercase tracking-wider mb-1.5">Maiden Surname</label>
                <input
                  id="input-maiden-name"
                  type="text"
                  value={maidenName}
                  onChange={(e) => setMaidenName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#161616] border border-[#2A2A28] text-xs text-[#E5E5E5] placeholder-[#444] rounded-none focus:outline-none focus:border-[#C5A059] transition-colors"
                  placeholder="Birth maiden surname"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3.5">
              <div>
                <label className="block text-[#666] text-[9px] font-mono uppercase tracking-wider mb-1.5">Nickname / Moniker</label>
                <input
                  id="input-nickname"
                  type="text"
                  value={nickname}
                  onChange={(e) => setNickname(e.target.value)}
                  className="w-full px-3 py-2 bg-[#161616] border border-[#2A2A28] text-xs text-[#E5E5E5] placeholder-[#444] rounded-none focus:outline-none focus:border-[#C5A059] transition-colors"
                  placeholder="Short moniker"
                />
              </div>

              <div>
                <label className="block text-[#666] text-[9px] font-mono uppercase tracking-wider mb-1.5">Profile Suffix</label>
                <input
                  id="input-suffix"
                  type="text"
                  value={suffix}
                  onChange={(e) => setSuffix(e.target.value)}
                  className="w-full px-3 py-2 bg-[#161616] border border-[#2A2A28] text-xs text-[#E5E5E5] placeholder-[#444] rounded-none focus:outline-none focus:border-[#C5A059] transition-colors"
                  placeholder="Jr., III, Sr."
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 items-center">
              <div>
                <label className="block text-[#666] text-[9px] font-mono uppercase tracking-wider mb-1.5">Biological Gender</label>
                <div className="flex gap-2.5">
                  {(['male', 'female', 'nonbinary'] as Gender[]).map(g => (
                    <button
                      key={g}
                      id={`gender-toggle-${g}`}
                      type="button"
                      onClick={() => setGender(g)}
                      className={`flex-1 py-1.5 px-1 border text-[10px] font-mono uppercase tracking-wider rounded-none transition-all cursor-pointer ${
                        gender === g 
                          ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#C5A059] font-bold' 
                          : 'border-[#2A2A28] bg-[#111] text-[#666] hover:text-[#AAA]'
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[#666] text-[9px] font-mono uppercase tracking-wider mb-1.5">Lifetime Status</label>
                <button
                  id="deceased-toggle-btn"
                  type="button"
                  onClick={() => setIsDeceased(!isDeceased)}
                  className={`w-full py-1.5 px-3 border text-[10px] font-mono uppercase tracking-widest rounded-none transition-all cursor-pointer ${
                    isDeceased 
                      ? 'border-red-950/60 bg-red-950/20 text-red-400' 
                      : 'border-emerald-950/60 bg-emerald-950/20 text-emerald-400'
                  }`}
                >
                  {isDeceased ? '✝ Deceased / Ancestor' : '🟢 Living Descendant'}
                </button>
              </div>
            </div>
          </div>

          <hr className="border-[#2A2A28]" />

          {/* Section 2: Birth & Death */}
          <div className="space-y-4">
            <h4 className="text-[10px] uppercase tracking-widest text-[#C5A059] border-b border-[#2A2A28] pb-1.5 flex items-center gap-1.5 font-mono">
              ⏳ Vital Milestones
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Birth info */}
              <div className="bg-[#111111] p-3.5 border border-[#2A2A28] space-y-3">
                <span className="text-[9px] font-bold text-[#666] font-mono tracking-widest uppercase">Birth Milestone</span>
                <div>
                  <label className="block text-[10px] text-[#555] mb-1">Birth Date</label>
                  <input
                    id="input-birth-date"
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#161616] border border-[#2A2A28] text-xs text-[#E5E5E5] rounded-none outline-none focus:border-[#C5A059]"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-[#555] mb-1">Birth Place</label>
                  <input
                    id="input-birth-place"
                    type="text"
                    value={birthPlace}
                    onChange={(e) => setBirthPlace(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#161616] border border-[#2A2A28] text-xs text-[#E5E5E5] placeholder-[#444] rounded-none outline-none focus:border-[#C5A059]"
                    placeholder="City, Parish / State"
                  />
                </div>
              </div>

              {/* Death info */}
              <div className={`p-4 transition-all space-y-3 border ${
                isDeceased ? 'bg-[#111111] border-[#2A2A28]' : 'bg-[#0A0A0A] border-[#202020] opacity-40'
              }`}>
                <span className="text-[9px] font-bold text-[#666] font-mono tracking-widest uppercase">Passing Milestone</span>
                <div>
                  <label className="block text-[10px] text-[#555] mb-1">Passing Date</label>
                  <input
                    id="input-death-date"
                    type="date"
                    disabled={!isDeceased}
                    value={deathDate}
                    onChange={(e) => setDeathDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#161616] border border-[#2A2A28] text-xs text-[#E5E5E5] rounded-none outline-none focus:border-[#C5A059] disabled:bg-[#0D0D0D]"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-[#555] mb-1">Passing Place</label>
                  <input
                    id="input-death-place"
                    type="text"
                    disabled={!isDeceased}
                    value={deathPlace}
                    onChange={(e) => setDeathPlace(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#161616] border border-[#2A2A28] text-xs text-[#E5E5E5] placeholder-[#444] rounded-none outline-none focus:border-[#C5A059] disabled:bg-[#0D0D0D]"
                    placeholder="City, County / Country"
                  />
                </div>
              </div>
            </div>
          </div>

          <hr className="border-[#2A2A28]" />

          {/* Section 3: Ancestry Links */}
          <div className="space-y-4">
            <h4 className="text-[10px] uppercase tracking-widest text-[#C5A059] border-b border-[#2A2A28] pb-1.5 flex items-center gap-1.5 font-mono">
              🧬 Direct Ancestral Lineage Connections
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[9px] font-mono text-[#666] uppercase tracking-wider mb-1.5">Direct Father Record</label>
                <select
                  id="select-father"
                  value={fatherId}
                  onChange={(e) => setFatherId(e.target.value)}
                  className="w-full px-3 py-2 bg-[#161616] border border-[#2A2A28] text-xs text-[#AAA] rounded-none outline-none focus:border-[#C5A059] cursor-pointer"
                >
                  <option value="">-- No Direct Patriarch Record --</option>
                  {potentialFathers.map(f => (
                    <option key={f.id} value={f.id}>{f.firstName} {f.lastName} ({f.birthDate ? f.birthDate.split('-')[0] : 'Unknown Yr'})</option>
                  ))}
                </select>
                <span className="text-[9px] text-[#555] mt-1 block font-sans">Query only lists registered male lines in active canvas workspace.</span>
              </div>

              <div>
                <label className="block text-[9px] font-mono text-[#666] uppercase tracking-wider mb-1.5">Direct Mother Record</label>
                <select
                  id="select-mother"
                  value={motherId}
                  onChange={(e) => setMotherId(e.target.value)}
                  className="w-full px-3 py-2 bg-[#161616] border border-[#2A2A28] text-xs text-[#AAA] rounded-none outline-none focus:border-[#C5A059] cursor-pointer"
                >
                  <option value="">-- No Direct Matriarch Record --</option>
                  {potentialMothers.map(m => (
                    <option key={m.id} value={m.id}>{m.firstName} {m.lastName} ({m.birthDate ? m.birthDate.split('-')[0] : 'Unknown Yr'})</option>
                  ))}
                </select>
                <span className="text-[9px] text-[#555] mt-1 block font-sans">Query only lists registered female lines in active canvas workspace.</span>
              </div>
            </div>
          </div>

          <hr className="border-[#2A2A28]" />

          {/* Section 4: Secondary Memoirs */}
          <div className="space-y-4">
            <h4 className="text-[10px] uppercase tracking-widest text-[#C5A059] border-b border-[#2A2A28] pb-1.5 flex items-center gap-1.5 font-mono">
              💼 Career & Chronicles
            </h4>
            <div className="space-y-4">
              <div>
                <label className="block text-[#666] text-[9px] font-mono uppercase tracking-wider mb-1.5">Archival Occupation or Main Title</label>
                <input
                  id="input-occupation"
                  type="text"
                  value={occupation}
                  onChange={(e) => setOccupation(e.target.value)}
                  className="w-full px-3 py-2 bg-[#161616] border border-[#2A2A28] text-xs text-[#E5E5E5] placeholder-[#444] rounded-none focus:outline-none focus:border-[#C5A059]"
                  placeholder="eg. High Sheriff, Preservator of Antiquities"
                />
              </div>

              <div>
                <label className="block text-[#666] text-[9px] font-mono uppercase tracking-wider mb-1.5">Biographical Memoir & Historical Chronicle</label>
                <textarea
                  id="input-biography"
                  value={biography}
                  onChange={(e) => setBiography(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 bg-[#161616] border border-[#2A2A28] text-xs text-[#E5E5E5] placeholder-[#444] rounded-none focus:outline-none focus:border-[#C5A059] resize-none scrollbar-thin"
                  placeholder="Document achievements, honors, residence changes, marital stories, and historic memoirs..."
                />
              </div>

              {/* Accent Color Picker formatted for luxury dashboard */}
              <div>
                <label className="block text-[#666] text-[9px] font-mono uppercase tracking-wider mb-1.5">Visual Identity Profile Color Accent</label>
                <div className="flex gap-2 flex-wrap p-2 border border-[#2A2A28] rounded-none bg-[#0A0A0A]">
                  {AVATAR_BG_COLORS.map(colorClass => (
                    <button
                      key={colorClass}
                      id={`color-preset-${colorClass.split(' ')[0]}`}
                      type="button"
                      onClick={() => setAvatarColor(colorClass)}
                      className={`w-7 h-7 rounded-none flex items-center justify-center text-[8px] font-bold border transition-transform ${colorClass} ${
                        avatarColor === colorClass ? 'scale-110 border-2 border-[#C5A059] z-10 font-bold' : 'hover:scale-105 opacity-80'
                      }`}
                    >
                      {avatarColor === colorClass ? '✓' : 'Aa'}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </form>

        {/* Modal Footer Controls */}
        <div className="p-4 border-t border-[#2A2A28] bg-[#0A0A0A] shrink-0 flex items-center justify-end gap-3.5">
          <button
            type="button"
            onClick={onClose}
            className="py-2.5 px-4 text-[#888] hover:text-[#E2E2E2] font-mono text-[10px] uppercase tracking-widest transition-colors cursor-pointer"
            id="modal-cancel-btn"
          >
            Cancel
          </button>
          
          <button
            type="button"
            onClick={handleFormSubmit}
            className="py-2.5 px-6 bg-[#C5A059] hover:bg-[#DFCA9B] text-black font-serif font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer"
            id="modal-save-btn"
          >
            <Save size={13} />
            Commit Archive
          </button>
        </div>

      </div>
    </div>
  );
}
