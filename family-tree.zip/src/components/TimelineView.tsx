/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Calendar, Baby, Heart, ShieldAlert, ArrowRight, Activity, Clock, SlidersHorizontal
} from 'lucide-react';
import { FamilyTreeData, Person } from '../types';

interface TimelineViewProps {
  treeData: FamilyTreeData;
  onSelectPersonAndToggleTab: (person: Person) => void;
}

interface TimelineEvent {
  id: string;
  year: number;
  dateStr: string;
  type: 'birth' | 'death' | 'marriage';
  title: string;
  description: string;
  location?: string;
  primaryPerson: Person;
  secondaryPerson?: Person; // e.g. for marriage
}

export default function TimelineView({
  treeData,
  onSelectPersonAndToggleTab
}: TimelineViewProps) {
  const [filterType, setFilterType] = useState<'all' | 'birth' | 'death' | 'marriage'>('all');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Build the list of chronological timeline events
  const events: TimelineEvent[] = [];

  // Gather births
  treeData.people.forEach(p => {
    if (p.birthDate) {
      const year = parseInt(p.birthDate.split('-')[0]);
      if (!isNaN(year)) {
        events.push({
          id: `birth-${p.id}-${p.birthDate}`,
          year,
          dateStr: p.birthDate,
          type: 'birth',
          title: `Birth of ${p.firstName} ${p.lastName}`,
          description: p.biography 
            ? `${p.firstName} was born. ${p.biography.slice(0, 80)}...`
            : `${p.firstName} ${p.lastName} entered the family genealogy.`,
          location: p.birthPlace,
          primaryPerson: p
        });
      }
    }
  });

  // Gather deaths
  treeData.people.forEach(p => {
    if (p.isDeceased && p.deathDate) {
      const year = parseInt(p.deathDate.split('-')[0]);
      const birthYear = p.birthDate ? parseInt(p.birthDate.split('-')[0]) : null;
      const ageStr = birthYear && !isNaN(birthYear) ? ` at age ${year - birthYear}` : '';
      if (!isNaN(year)) {
        events.push({
          id: `death-${p.id}-${p.deathDate}`,
          year,
          dateStr: p.deathDate,
          type: 'death',
          title: `Passing of ${p.firstName} ${p.lastName}`,
          description: `${p.firstName} ${p.lastName} passed away${ageStr}.`,
          location: p.deathPlace,
          primaryPerson: p
        });
      }
    }
  });

  // Gather marriages
  treeData.marriages.forEach(m => {
    const p1 = treeData.people.find(p => p.id === m.person1Id);
    const p2 = treeData.people.find(p => p.id === m.person2Id);
    
    if (m.date && p1 && p2) {
      const year = parseInt(m.date.split('-')[0]);
      if (!isNaN(year)) {
        events.push({
          id: `marriage-${m.id}-${m.date}`,
          year,
          dateStr: m.date,
          type: 'marriage',
          title: `Marriage of ${p1.firstName} & ${p2.firstName}`,
          description: `A holy covenant was formed between ${p1.firstName} ${p1.lastName} and ${p2.firstName} ${p2.lastName}${m.isDivorced ? ' (Later divorced)' : ''}.`,
          location: m.place,
          primaryPerson: p1,
          secondaryPerson: p2
        });
      }
    }
  });

  // Apply filters
  const filteredEvents = events.filter(e => {
    if (filterType === 'all') return true;
    return e.type === filterType;
  });

  // Sort
  const sortedEvents = [...filteredEvents].sort((a, b) => {
    if (sortOrder === 'asc') {
      return a.year - b.year || a.dateStr.localeCompare(b.dateStr);
    } else {
      return b.year - a.year || b.dateStr.localeCompare(a.dateStr);
    }
  });

  const getEventIcon = (type: 'birth' | 'death' | 'marriage') => {
    switch (type) {
      case 'birth':
        return (
          <div className="w-8 h-8 rounded-none bg-[#111] text-[#C5A059] border border-[#C5A059] flex items-center justify-center shadow-none">
            <Baby size={14} />
          </div>
        );
      case 'marriage':
        return (
          <div className="w-8 h-8 rounded-none bg-[#111] text-pink-400 border border-pink-400/50 flex items-center justify-center shadow-none">
            <Heart size={14} />
          </div>
        );
      case 'death':
        return (
          <div className="w-8 h-8 rounded-none bg-[#111] text-red-400 border border-red-400/40 flex items-center justify-center shadow-none">
            <Activity size={14} />
          </div>
        );
    }
  };

  const formatDateLabel = (dateStr: string) => {
    try {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        const d = new Date(dateStr);
        if (!isNaN(d.getTime())) {
          return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
        }
      }
      return dateStr;
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#0A0A0A] p-6 sm:p-8 text-[#E5E5E5] relative" id="timeline-explorer">
      {/* Grid background dots texture */}
      <div className="absolute inset-0 bg-grid-dots opacity-5 pointer-events-none"></div>

      <div className="max-w-4xl mx-auto space-y-6 relative z-10">
        
        {/* View Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#0D0D0D] p-5 border border-[#2A2A28]">
          <div>
            <h2 className="text-base font-serif font-bold text-[#E5E5E5] flex items-center gap-2 tracking-wide leading-none">
              <Clock size={16} className="text-[#C5A059]" /> Chronological Milestones Registry
            </h2>
            <p className="text-[11px] text-[#888] mt-1 font-sans">Sequence of digitized events and life records sorted historically.</p>
          </div>

          {/* Filtering & Sorting Panel */}
          <div className="flex items-center gap-2 flex-wrap" id="timeline-controls-bar">
            {/* Filter Toggle */}
            <div className="flex bg-[#111111] p-1 border border-[#2A2A28] text-[10px] font-mono uppercase tracking-wider text-[#666]" id="timeline-type-filters">
              <button
                style={{ contentVisibility: 'auto' }}
                onClick={() => setFilterType('all')}
                className={`px-3 py-1.5 transition-colors cursor-pointer ${filterType === 'all' ? 'bg-[#1E1E1E] text-[#C5A059] border border-[#2A2A28] font-bold' : 'hover:text-[#AAA]'}`}
              >
                All
              </button>
              <button
                style={{ contentVisibility: 'auto' }}
                onClick={() => setFilterType('birth')}
                className={`px-3 py-1.5 transition-colors cursor-pointer ${filterType === 'birth' ? 'bg-[#1E1E1E] text-[#C5A059] border border-[#2A2A28] font-bold' : 'hover:text-[#AAA]'}`}
              >
                Births
              </button>
              <button
                style={{ contentVisibility: 'auto' }}
                onClick={() => setFilterType('marriage')}
                className={`px-3 py-1.5 transition-colors cursor-pointer ${filterType === 'marriage' ? 'bg-[#1E1E1E] text-[#C5A059] border border-[#2A2A28] font-bold' : 'hover:text-[#AAA]'}`}
              >
                Marriages
              </button>
              <button
                style={{ contentVisibility: 'auto' }}
                onClick={() => setFilterType('death')}
                className={`px-3 py-1.5 transition-colors cursor-pointer ${filterType === 'death' ? 'bg-[#1E1E1E] text-[#C5A059] border border-[#2A2A28] font-bold' : 'hover:text-[#AAA]'}`}
              >
                Passings
              </button>
            </div>

            {/* Sorting Toggle */}
            <button
              onClick={() => setSortOrder(o => o === 'asc' ? 'desc' : 'asc')}
              className="px-3 py-1.5 bg-[#111111] border border-[#2A2A28] text-[10px] font-mono uppercase tracking-widest text-[#AAA] hover:border-[#C5A059] hover:text-[#E5E5E5] transition-colors flex items-center gap-1.5 cursor-pointer"
              id="timeline-sort-btn"
            >
              Order: {sortOrder === 'asc' ? 'Earliest First' : 'Latest First'}
            </button>
          </div>
        </div>

        {/* Empty State */}
        {sortedEvents.length === 0 ? (
          <div className="bg-[#0D0D0D] p-12 text-center border border-[#2A2A28]">
            <SlidersHorizontal size={36} className="mx-auto text-[#444] mb-3" />
            <h4 className="text-[#C5A059] font-serif font-semibold tracking-wide">No Life Milestones Recorded</h4>
            <p className="text-[#666] text-xs max-w-xs mx-auto mt-2 leading-relaxed">
              No historical chronological entries matched the active filters. Ensure details like birth dates are logged in profiles.
            </p>
          </div>
        ) : (
          /* Timeline Tree Layout */
          <div className="relative border-l border-[#2A2A28] ml-4 sm:ml-40 pr-1 space-y-6" id="timeline-records-list">
            
            {sortedEvents.map((event) => {
              return (
                <div key={event.id} className="relative pl-6 group py-1.5" style={{ contentVisibility: 'auto' }}>
                  {/* Left-side absolute year bubble (only on larger screens) */}
                  <div className="absolute right-full mr-6 top-1.5 hidden sm:flex flex-col items-end">
                    <span className="text-sm font-black text-[#C5A059] font-mono tracking-wider">{event.year}</span>
                    <span className="text-[9px] text-[#555] uppercase tracking-widest font-mono font-medium">{event.dateStr.includes('-') && event.dateStr.split('-').length === 3 ? 'Exact Record' : 'Estimated'}</span>
                  </div>

                  {/* Absolute core timeline junction dot */}
                  <div className="absolute left-[-16px] top-2 z-10">
                    {getEventIcon(event.type)}
                  </div>

                  {/* Event details card */}
                  <div className="bg-[#0D0D0D] p-4 sm:p-5 border border-[#2A2A28] group-hover:border-[#C5A059] transition-all relative">
                    
                    {/* Floating year tag for mobile where left year bubble is hidden */}
                    <span className="sm:hidden inline-block px-2 py-0.5 border border-[#C5A059]/40 text-[#C5A059] font-mono text-[9px] font-bold rounded-none bg-[#111] mb-2">
                      Year {event.year}
                    </span>

                    <div className="flex flex-col sm:flex-row justify-between items-start gap-2">
                      <div>
                        <h4 className="text-xs font-serif font-bold tracking-wide text-[#E5E5E5] group-hover:text-[#C5A059] transition-colors">
                          {event.title}
                        </h4>
                        <span className="text-[10px] text-[#666] font-mono block mt-1">🗓️ {formatDateLabel(event.dateStr)} {event.location && `• 📍 ${event.location}`}</span>
                      </div>
                    </div>

                    <p className="text-xs text-[#AAA] font-serif leading-relaxed mt-2.5 max-w-2xl italic">
                      {event.description}
                    </p>

                    {/* Nodes links navigator */}
                    <div className="flex gap-2 mt-4 pt-3 border-t border-[#2A2A28] items-center">
                      <span className="text-[9px] text-[#555] font-mono uppercase tracking-widest font-semibold">Inspect Lineage:</span>
                      
                      <button
                        onClick={() => onSelectPersonAndToggleTab(event.primaryPerson)}
                        className="py-1 px-2.5 border border-[#2A2A28] hover:border-[#C5A059] text-[#C5A059] hover:bg-[#111] rounded-none text-[9px] font-mono uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer"
                      >
                        {event.primaryPerson.firstName} {event.primaryPerson.lastName}
                        <ArrowRight size={10} />
                      </button>

                      {event.secondaryPerson && (
                        <button
                          onClick={() => onSelectPersonAndToggleTab(event.secondaryPerson!)}
                          className="py-1 px-2.5 border border-[#2A2A28] hover:border-[#C5A059] text-[#C5A059] hover:bg-[#111] rounded-none text-[9px] font-mono uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer"
                        >
                          {event.secondaryPerson.firstName} {event.secondaryPerson.lastName}
                          <ArrowRight size={10} />
                        </button>
                      )}
                    </div>

                  </div>
                </div>
              );
            })}

          </div>
        )}

      </div>
    </div>
  );
}
