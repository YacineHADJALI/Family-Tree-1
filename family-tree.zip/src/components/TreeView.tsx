/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  User, Heart, ArrowUp, ArrowDown, Users, ChevronRight, 
  ZoomIn, ZoomOut, Maximize2, Plus, Edit3, Trash2, ShieldAlert
} from 'lucide-react';
import { FamilyTreeData, Person, Marriage } from '../types';

interface TreeViewProps {
  treeData: FamilyTreeData;
  activePerson: Person | null;
  onSelectPerson: (person: Person) => void;
  onEditPerson: (person: Person) => void;
  onAddRelation: (relatedToId: string, role: 'father' | 'mother' | 'spouse' | 'child') => void;
  onRemovePerson: (id: string) => void;
}

export default function TreeView({
  treeData,
  activePerson,
  onSelectPerson,
  onEditPerson,
  onAddRelation,
  onRemovePerson
}: TreeViewProps) {
  const [treeMode, setTreeMode] = useState<'focus' | 'pedigree' | 'descendants'>('focus');
  const [zoom, setZoom] = useState(1);
  const [panX, setPanX] = useState(0);
  const [panY, setPanY] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  if (!activePerson) {
    return (
      <div className="flex-1 bg-[#0A0A0A] flex flex-col items-center justify-center p-8 text-center" id="empty-tree-placeholder">
        <Users size={48} className="text-[#C5A059]/40 mb-4 animate-pulse" />
        <h3 className="text-[#C5A059] font-serif font-bold tracking-wide text-lg">No Active Archivist Selected</h3>
        <p className="text-[#888] text-xs max-w-sm mt-2 mb-4 leading-relaxed font-sans">
          Select a member from the sidebar list or click the button below to registry your first member of the tree.
        </p>
      </div>
    );
  }

  // Helper selectors
  const getPersonById = (id?: string) => treeData.people.find(p => p.id === id);

  // Focus tree relationships:
  const father = activePerson.fatherId ? getPersonById(activePerson.fatherId) : null;
  const mother = activePerson.motherId ? getPersonById(activePerson.motherId) : null;

  // Spouses: find all marriages where activePerson is involved
  const activeMarriages = treeData.marriages.filter(m => 
    m.person1Id === activePerson.id || m.person2Id === activePerson.id
  );
  const spouses = activeMarriages.map(m => {
    const spouseId = m.person1Id === activePerson.id ? m.person2Id : m.person1Id;
    return {
      spouse: getPersonById(spouseId),
      marriageDetails: m
    };
  }).filter(s => s.spouse !== undefined) as { spouse: Person, marriageDetails: Marriage }[];

  // Children: people whose fatherId or motherId is activePerson.id
  const children = treeData.people.filter(p => 
    p.fatherId === activePerson.id || p.motherId === activePerson.id
  );

  // Siblings: people sharing same father or mother
  const siblings = treeData.people.filter(p => 
    p.id !== activePerson.id && 
    (
      (activePerson.fatherId && p.fatherId === activePerson.fatherId) || 
      (activePerson.motherId && p.motherId === activePerson.motherId)
    )
  );

  // Drag and pan canvas events
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    const target = e.target as HTMLElement;
    if (target.closest('.interactive-node-card') || target.closest('button')) return;
    
    setIsDragging(true);
    setDragStart({ x: e.clientX - panX, y: e.clientY - panY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPanX(e.clientX - dragStart.x);
    setPanY(e.clientY - dragStart.y);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleZoom = (direction: 'in' | 'out' | 'reset') => {
    if (direction === 'in') setZoom(z => Math.min(1.5, z + 0.1));
    else if (direction === 'out') setZoom(z => Math.max(0.6, z - 0.1));
    else {
      setZoom(1);
      setPanX(0);
      setPanY(0);
    }
  };

  // Safe gender colors and styling lookup mapped to Luxury Sophisticated Dark palette
  const getGenderStyle = (p: Person) => {
    if (p.isDeceased) {
      return 'border-[#222220] bg-[#0A0A0A] text-[#666] opacity-60';
    }
    return 'border-[#2A2A28] bg-[#0D0D0D] text-[#AAA] hover:border-[#C5A059] hover:bg-[#121210]';
  };

  const getGenderBadge = (p: Person) => {
    if (p.isDeceased) return <span className="text-[8px] bg-[#1A1A1A] text-[#666] px-1.5 py-0.5 border border-[#2A2A28] lowercase tracking-widest font-mono font-medium">† deceased</span>;
    switch (p.gender) {
      case 'male': return <span className="text-[8px] bg-transparent border border-[#555] text-[#AAA] px-1.5 py-0.5 tracking-widest uppercase font-mono font-light">Male</span>;
      case 'female': return <span className="text-[8px] bg-transparent border border-[#555] text-[#AAA] px-1.5 py-0.5 tracking-widest uppercase font-mono font-light">Female</span>;
      default: return <span className="text-[8px] bg-transparent border border-[#555] text-[#AAA] px-1.5 py-0.5 tracking-widest uppercase font-mono font-light">{p.gender}</span>;
    }
  };

  // Helper compiler for a member card (designed with luxury vintage style nodes)
  const renderMemberCard = (p: Person, subtitle?: string, highlight = false) => {
    const isFocused = p.id === activePerson.id;
    const age = p.birthDate ? calculateAge(p.birthDate, p.deathDate) : null;
    const yearSpan = p.birthDate 
      ? `${p.birthDate.split('-')[0]}${p.isDeceased ? ` – ${p.deathDate ? p.deathDate.split('-')[0] : '✝'}` : ''}`
      : 'Unknown';

    return (
      <div 
        key={p.id}
        id={`tree-node-${p.id}`}
        className={`interactive-node-card w-48 shrink-0 border p-3 block text-left transition-all ${
          isFocused 
            ? 'border-2 border-[#C5A059] bg-[#161616] text-[#E5E5E5] shadow-[0_0_15px_rgba(197,160,89,0.25)] scale-102 z-10'
            : getGenderStyle(p)
        } ${highlight && !isFocused ? 'shadow-[0_0_8px_rgba(197,160,89,0.1)] border-[#C5A059]/50' : 'shadow-none'}`}
      >
        <div className="flex items-start justify-between gap-1.5">
          <div className="flex flex-col min-w-0">
            <span className="text-[9px] font-mono text-[#666] leading-none mb-1 font-semibold uppercase tracking-widest">{subtitle || yearSpan}</span>
            <div className="flex items-center gap-1 min-w-0">
              <h4 className={`text-xs font-serif font-bold leading-normal truncate ${isFocused ? 'text-[#C5A059]' : 'text-[#E5E5E5]'}`} id={`node-name-${p.id}`}>
                {p.firstName} {p.lastName}
              </h4>
              {p.suffix && <span className="text-[9px] text-[#666] shrink-0 font-mono font-medium">{p.suffix}</span>}
            </div>
            {p.nickname && <p className="text-[10px] text-[#666] italic font-serif">"{p.nickname}"</p>}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <div className={`w-6 h-6 rounded-none flex items-center justify-center font-serif font-bold text-[9px] border ${
              isFocused 
                ? 'bg-[#C5A059] text-black border-[#C5A059]' 
                : 'bg-[#1A1A1A] text-[#888] border-[#2A2A28]'
            }`}>
              {p.firstName[0]}{p.lastName[0] || ''}
            </div>
          </div>
        </div>

        <p className="text-[10px] text-[#666] leading-tight mt-1 level-clamp-1 italic font-serif">
          {p.occupation || 'No credentials logged'}
        </p>

        <div className="mt-2 pt-2 border-t border-[#2A2A28] flex items-center justify-between text-[8px] text-[#666]">
          <span>{getGenderBadge(p)}</span>
          {age !== null && (
            <span className="font-mono font-semibold text-[#888] bg-[#161616] px-1 border border-[#2A2A28]">
              {p.isDeceased ? `Aged ${age}` : `${age} yrs`}
            </span>
          )}
        </div>

        {/* Quick actions styled elegantly */}
        <div className="flex items-center justify-end gap-2 mt-2 pt-1.5 border-t border-dashed border-[#242422]">
          {!isFocused && (
            <button
              id={`node-focus-btn-${p.id}`}
              onClick={() => onSelectPerson(p)}
              className="p-1 hover:bg-[#1E1E1D] text-[#888] hover:text-[#C5A059] transition-colors cursor-pointer"
              title="Focus Lineage"
            >
              <Maximize2 size={11} />
            </button>
          )}
          <button
            id={`node-edit-btn-${p.id}`}
            onClick={() => onEditPerson(p)}
            className="p-1 hover:bg-[#1E1E1D] text-[#888] hover:text-[#C5A059] transition-colors cursor-pointer"
            title="Edit Details"
          >
            <Edit3 size={11} />
          </button>
          <button
            id={`node-delete-btn-${p.id}`}
            onClick={(e) => {
              e.stopPropagation();
              if (confirm(`Remove ${p.firstName} ${p.lastName} from family tree? Note that descendants parents mapping may be unlinked.`)) {
                onRemovePerson(p.id);
              }
            }}
            className="p-1 hover:bg-red-950/20 text-[#666] hover:text-red-405 transition-colors cursor-pointer"
            title="Remove Member"
          >
            <Trash2 size={11} />
          </button>
        </div>
      </div>
    );
  };

  const renderEmptySlot = (role: 'father' | 'mother' | 'spouse' | 'child', relatedTo: Person) => {
    return (
      <button
        style={{ contentVisibility: 'auto' }}
        id={`add-relation-slot-${role}-${relatedTo.id}`}
        onClick={() => onAddRelation(relatedTo.id, role)}
        className="w-48 shrink-0 rounded-none border border-dashed border-[#2A2A28] hover:border-[#C5A059] hover:bg-[#111110]/50 p-3 flex flex-col items-center justify-center text-center gap-1.5 shadow-none transition-all opacity-60 hover:opacity-100 h-[110px] cursor-pointer"
      >
        <span className="p-1 bg-[#1A1A1A] border border-[#2A2A28] rounded-none text-[#C5A059]/70 group-hover:text-[#C5A059] transition-colors">
          <Plus size={12} />
        </span>
        <div className="text-[9px] font-mono tracking-widest text-[#666] uppercase">Add {role}</div>
      </button>
    );
  };

  const renderPedigreeView = () => {
    const renderPedigreeNode = (personId?: string, gen = 0, roleName = 'Focus'): React.ReactNode => {
      const person = personId ? getPersonById(personId) : null;
      
      return (
        <div className="flex items-center gap-6" style={{ contentVisibility: 'auto' }}>
          {person ? (
            renderMemberCard(person, roleName)
          ) : (
            <button
              onClick={() => {
                if (gen > 0) {
                  alert("To add ancestors, navigate to the closest existing family member, and add their father or mother.");
                }
              }}
              className="w-48 shrink-0 rounded-none border border-dashed border-[#2A2A28] bg-[#0D0D0D]/40 p-4 h-[110px] flex flex-col items-center justify-center text-[#555] hover:border-[#C5A059] hover:bg-[#111] transition-all text-xs text-center leading-normal cursor-pointer"
            >
              <User size={14} className="text-[#333]" />
              <span className="font-mono text-[9px] tracking-widest uppercase mt-1">{roleName}</span>
              <span className="text-[8px] text-[#444] mt-0.5">Focus left to add</span>
            </button>
          )}

          {gen < 3 && (
            <div className="flex flex-col gap-4 border-l border-[#2A2A28] pl-6 relative">
              <div className="absolute left-0 top-6 bottom-6 w-px bg-[#2A2A28]"></div>
              
              {person ? (
                <>
                  {renderPedigreeNode(person.fatherId, gen + 1, person.gender === 'female' ? "Paternal grandfather" : "Father")}
                  {renderPedigreeNode(person.motherId, gen + 1, person.gender === 'female' ? "Mother" : "Mother")}
                </>
              ) : (
                <>
                  {renderPedigreeNode(undefined, gen + 1, "Ancestor father")}
                  {renderPedigreeNode(undefined, gen + 1, "Ancestor mother")}
                </>
              )}
            </div>
          )}
        </div>
      );
    };

    return (
      <div className="flex items-center justify-start p-12 min-w-full min-h-full" id="pedigree-scroller">
        {renderPedigreeNode(activePerson.id, 0, "Focused lineage")}
      </div>
    );
  };

  const renderFocusTree = () => {
    return (
      <div className="flex flex-col items-center gap-12 p-8 min-w-full min-h-full" id="focus-levels-panel">
        {/* Generational Level 1: Parents */}
        <div className="flex flex-col items-center">
          <div className="flex items-center gap-8 relative pb-2">
            <div className="flex flex-col items-center">
              <span className="text-[9px] text-[#666] font-mono tracking-widest uppercase mb-1.5 font-bold">Patriarch</span>
              {father ? renderMemberCard(father, 'Patriarch') : renderEmptySlot('father', activePerson)}
            </div>
            
            {/* Heart / marriage indicator but golden styled */}
            <div className="flex flex-col items-center justify-center z-1 w-8 h-8 rounded-none bg-[#0D0D0D] border border-[#2A2A28] text-[#C5A059] mt-5 shrink-0 font-bold text-xs shadow-none" title="Conjugal Union">
              💍
            </div>

            <div className="flex flex-col items-center">
              <span className="text-[9px] text-[#666] font-mono tracking-widest uppercase mb-1.5 font-bold">Matriarch</span>
              {mother ? renderMemberCard(mother, 'Matriarch') : renderEmptySlot('mother', activePerson)}
            </div>
          </div>
          {/* Vertical stem going down from parents connection */}
          <div className="w-0.5 h-6 bg-[#2A2A28]"></div>
        </div>

        {/* Generational Level 2: Core Focus Person & Spouse & Siblings */}
        <div className="flex items-center gap-8 py-4 bg-[#0D0D0D]/90 p-4 px-6 rounded-none border border-[#2A2A28] shadow-none">
          {/* Siblings group panel (rendered to left) */}
          {siblings.length > 0 && (
            <div className="flex flex-col gap-2.5 border-r border-[#2A2A28] pr-8">
              <span className="text-[9px] text-[#666] font-mono tracking-widest uppercase font-semibold text-center mb-1">Siblings ({siblings.length})</span>
              <div className="flex flex-col gap-2 max-h-48 overflow-y-auto p-1 scrollbar-thin">
                {siblings.map(sib => renderMemberCard(sib, 'Sibling'))}
              </div>
            </div>
          )}

          {/* Focal member node */}
          <div className="flex flex-col items-center">
            <span className="text-[9px] text-[#C5A059] font-mono tracking-widest uppercase font-extrabold mb-1.5 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059] animate-ping"></span> FOCUSED ARCHIVE
            </span>
            {renderMemberCard(activePerson, undefined, true)}
          </div>

          {/* Marriages / Spouses group node */}
          <div className="flex items-center gap-4 border-l border-[#2A2A28] pl-8">
            {spouses.length > 0 ? (
              <div className="flex flex-col gap-3">
                <span className="text-[9px] text-[#C5A059] font-mono tracking-widest uppercase font-bold text-center">Conjugal Partner</span>
                {spouses.map(({ spouse }) => renderMemberCard(spouse, 'Partner'))}
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <span className="text-[9px] text-[#666] font-mono tracking-widest uppercase font-semibold mb-1.5">Conjugal Partner</span>
                {renderEmptySlot('spouse', activePerson)}
              </div>
            )}
          </div>
        </div>

        {/* Generational Level 3: Children */}
        <div className="flex flex-col items-center pl-1">
          {/* Stem going down from focus card to children */}
          <div className="w-0.5 h-8 bg-[#2A2A28]"></div>
          
          <div className="relative pt-1">
            <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-[9px] font-mono text-[#AAA] tracking-widest uppercase font-bold bg-[#0A0A0A] border border-[#2A2A28] px-2.5 py-0.5">Descendants ({children.length})</span>
            
            <div className="flex items-start gap-6 pt-5">
              {children.map(child => renderMemberCard(child, 'Descendant'))}
              {renderEmptySlot('child', activePerson)}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderDescendantsTreeView = () => {
    // Deep descendant crawler nested nodes
    const renderNodeFolder = (person: Person, depth = 0): React.ReactNode => {
      const pChildren = treeData.people.filter(p => p.fatherId === person.id || p.motherId === person.id);
      
      return (
        <div key={person.id} className="ml-4 pl-4 border-l border-[#2A2A28] space-y-2 relative" style={{ contentVisibility: 'auto' }}>
          <div className="absolute top-[18px] left-0 w-4 h-px bg-[#2A2A28]"></div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={() => onSelectPerson(person)}
              className={`text-left py-1.5 px-3 rounded-none flex items-center gap-2.5 group transition-colors cursor-pointer border ${
                activePerson.id === person.id 
                  ? 'bg-[#C5A059] text-black border-[#C5A059] font-bold' 
                  : 'bg-[#111] text-[#AAA] border-[#2A2A28] hover:bg-[#161616]'
              }`}
            >
              <div className={`w-5 h-5 rounded-none flex items-center justify-center font-bold text-[8px] ${
                activePerson.id === person.id ? 'bg-black/10 text-black border-transparent' : person.avatarColor || 'bg-[#1A1A1A] border-[#2A2A28]'
              }`}>
                {person.firstName[0]}
              </div>
              <span className="text-xs font-serif font-bold tracking-wide">
                {person.firstName} {person.lastName}
              </span>
              <span className={`text-[9px] font-mono leading-none ${activePerson.id === person.id ? 'text-black/60' : 'text-[#666]'}`}>
                {person.birthDate ? `(${person.birthDate.split('-')[0]})` : ''}
              </span>
              {person.occupation && (
                <span className={`text-[9px] italic max-w-[120px] truncate ${activePerson.id === person.id ? 'text-black/60 font-serif' : 'text-[#555] font-serif'}`}>
                  • {person.occupation}
                </span>
              )}
            </button>
            
            <button
              onClick={() => onAddRelation(person.id, 'child')}
              className="p-1 rounded-none border border-[#2A2A28] hover:border-[#C5A059] hover:bg-[#1A1A1A] text-[#666] hover:text-[#C5A059] cursor-pointer"
              title="Add Child to member"
            >
              <Plus size={10} />
            </button>
          </div>

          {pChildren.length > 0 && (
            <div className="space-y-2 pt-1 pb-1">
              {pChildren.map(child => renderNodeFolder(child, depth + 1))}
            </div>
          )}
        </div>
      );
    };

    return (
      <div className="p-8 max-w-2xl mx-auto bg-[#0D0D0D] rounded-none border border-[#2A2A28] shadow-none" id="descendants-crawl">
        <div className="mb-4">
          <h3 className="text-sm font-serif font-bold tracking-wider text-[#C5A059]">Archival Lineage Cascade</h3>
          <p className="text-[11px] text-[#666] font-sans">Detailed directory cascading down chronologically from {activePerson.firstName} {activePerson.lastName}.</p>
        </div>
        <div className="space-y-2 mt-4 ml-[-16px]">
          {renderNodeFolder(activePerson, 0)}
        </div>
      </div>
    );
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0A0A0A] overflow-hidden relative" id="tree-canvas-panel">
      {/* Grid Overlay Texture with 5% opacity */}
      <div className="absolute inset-0 bg-grid-dots opacity-5 pointer-events-none"></div>

      {/* Canvas Tool-Bar */}
      <div className="absolute top-4 left-4 right-4 z-20 flex flex-wrap gap-2.5 items-center justify-between" id="canvas-toolbar">
        {/* Toggle Mode Control styled with luxury serif layout traits */}
        <div className="bg-[#0D0D0D] p-1 shadow-none border border-[#2A2A28] flex gap-1 text-[11px] font-mono text-[#888]" id="view-mode-toggles">
          <button
            id="view-mode-focus"
            onClick={() => { setTreeMode('focus'); handleZoom('reset'); }}
            className={`px-3.5 py-1.5 transition-all flex items-center gap-1.5 cursor-pointer rounded-none uppercase font-semibold ${
              treeMode === 'focus' ? 'bg-[#1A1A1A] border border-[#2A2A28] text-[#C5A059]' : 'hover:bg-[#121212] hover:text-[#E5E5E5]'
            }`}
          >
            <Users size={12} />
            Focus Node
          </button>
          <button
            id="view-mode-pedigree"
            onClick={() => { setTreeMode('pedigree'); handleZoom('reset'); }}
            className={`px-3.5 py-1.5 transition-all flex items-center gap-1.5 cursor-pointer rounded-none uppercase font-semibold ${
              treeMode === 'pedigree' ? 'bg-[#1A1A1A] border border-[#2A2A28] text-[#C5A059]' : 'hover:bg-[#121212] hover:text-[#E5E5E5]'
            }`}
          >
            <ArrowUp size={12} />
            Pedigree Tree
          </button>
          <button
            id="view-mode-descendants"
            onClick={() => { setTreeMode('descendants'); handleZoom('reset'); }}
            className={`px-3.5 py-1.5 transition-all flex items-center gap-1.5 cursor-pointer rounded-none uppercase font-semibold ${
              treeMode === 'descendants' ? 'bg-[#1A1A1A] border border-[#2A2A28] text-[#C5A059]' : 'hover:bg-[#121212] hover:text-[#E5E5E5]'
            }`}
          >
            <ArrowDown size={12} />
            Descendants List
          </button>
        </div>

        {/* Zoom and Navigation controls */}
        <div className="bg-[#0D0D0D] p-1 border border-[#2A2A28] flex items-center gap-0.5" id="navigation-controls">
          <button
            id="zoom-in-btn"
            onClick={() => handleZoom('in')}
            className="p-1.5 hover:bg-[#1A1A1A] text-[#888] hover:text-[#C5A059] rounded-none transition-colors cursor-pointer"
            title="Zoom In"
          >
            <ZoomIn size={13} />
          </button>
          <button
            id="zoom-out-btn"
            onClick={() => handleZoom('out')}
            className="p-1.5 hover:bg-[#1A1A1A] text-[#888] hover:text-[#C5A059] rounded-none transition-colors cursor-pointer"
            title="Zoom Out"
          >
            <ZoomOut size={13} />
          </button>
          <div className="w-px h-4 bg-[#2A2A28] mx-1"></div>
          <button
            id="zoom-reset-btn"
            onClick={() => handleZoom('reset')}
            className="px-2.5 py-1 text-[9px] uppercase tracking-widest font-mono hover:bg-[#1A1A1A] text-[#666] hover:text-[#C5A059] rounded-none transition-colors cursor-pointer"
            title="Recenter Chart"
          >
            Reset
          </button>
        </div>
      </div>

      {/* Actual pan and Zoom canvas board */}
      <div 
        className={`flex-1 overflow-auto select-none outline-none relative bg-[radial-gradient(circle_at_center,_#141412_0%,_#0A0A0A_100%)] ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        id="canvas-draggable-viewport"
      >
        <div 
          className="absolute origin-center transition-transform duration-75 min-w-full min-h-full"
          style={{
            transform: `translate(${panX}px, ${panY}px) scale(${zoom})`,
          }}
          id="canvas-scalable-container"
        >
          {treeMode === 'focus' && renderFocusTree()}
          {treeMode === 'pedigree' && renderPedigreeView()}
          {treeMode === 'descendants' && renderDescendantsTreeView()}
        </div>
      </div>

      {/* User Guides Overlay styled elegantly with gold/dark bounds */}
      <div className="absolute bottom-4 left-4 p-3.5 bg-[#0D0D0D]/90 rounded-none border border-[#2A2A28] text-[9px] text-[#888] leading-relaxed max-w-xs space-y-1 backdrop-blur-xs z-10 select-text">
        <p className="font-serif font-semibold text-[#C5A059] tracking-wider uppercase flex items-center gap-1.5">💡 Interactive Sandbox Tip</p>
        <p className="font-sans text-[#666]">Drag empty canvas spacing to pan around. Tap responsive slots (<code className="bg-[#111] font-mono text-[9px] text-[#C5A059]">Add ...</code>) to expand the family tree instantly.</p>
      </div>

      {/* Legend Overlay as shown in the design template */}
      <div className="absolute bottom-4 right-4 bg-[#0D0D0D]/90 border border-[#2A2A28] p-3 text-[9px] tracking-[0.15em] uppercase text-[#666] flex flex-col gap-1.5">
        <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-none bg-[#C5A059]"></span> Selected Profile</div>
        <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-none bg-[#0D0D0D] border border-[#2A2A28]"></span> Lineage Ancestral</div>
        <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-none border border-[#C5A059]"></span> Patriarch / Matriarch</div>
      </div>
    </div>
  );
}

// Helpers
function calculateAge(birth: string, death?: string): number | null {
  try {
    const start = new Date(birth);
    if (isNaN(start.getTime())) return null;
    const end = death ? new Date(death) : new Date('2026-06-20');
    let age = end.getFullYear() - start.getFullYear();
    const monthDiff = end.getMonth() - start.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && end.getDate() < start.getDate())) {
      age--;
    }
    return isNaN(age) || age < 0 ? 0 : age;
  } catch (err) {
    return null;
  }
}
