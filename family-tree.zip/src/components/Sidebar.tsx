/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { 
  Search, Plus, Download, Upload, Trash2, 
  User, RefreshCw, BarChart2, Calendar, Database, Sparkles, BookOpen
} from 'lucide-react';
import { FamilyTreeData, Person } from '../types';
import { PRELOADED_TREES } from '../preloadedTrees';

interface SidebarProps {
  treeData: FamilyTreeData;
  activePerson: Person | null;
  onSelectPerson: (person: Person) => void;
  onAddPerson: () => void;
  onLoadTree: (tree: FamilyTreeData) => void;
  onImportTree: (data: FamilyTreeData) => void;
  onResetTree: () => void;
  activeTab: 'tree' | 'timeline' | 'analytics';
  setActiveTab: (tab: 'tree' | 'timeline' | 'analytics') => void;
}

export default function Sidebar({
  treeData,
  activePerson,
  onSelectPerson,
  onAddPerson,
  onLoadTree,
  onImportTree,
  onResetTree,
  activeTab,
  setActiveTab
}: SidebarProps) {
  const [subTab, setSubTab] = useState<'people' | 'presets' | 'import-export'>('people');
  const [searchQuery, setSearchQuery] = useState('');
  const [genderFilter, setGenderFilter] = useState<'all' | 'male' | 'female' | 'other'>('all');
  const [deceasedFilter, setDeceasedFilter] = useState<'all' | 'living' | 'deceased'>('all');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Filters the list of people
  const filteredPeople = treeData.people.filter(p => {
    const fullName = `${p.firstName} ${p.lastName} ${p.nickname || ''} ${p.maidenName || ''}`.toLowerCase();
    const matchesSearch = fullName.includes(searchQuery.toLowerCase()) || 
      (p.occupation && p.occupation.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (p.birthPlace && p.birthPlace.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesGender = genderFilter === 'all' || p.gender === genderFilter;
    
    const matchesDeceased = deceasedFilter === 'all' || 
      (deceasedFilter === 'living' && !p.isDeceased) || 
      (deceasedFilter === 'deceased' && p.isDeceased);

    return matchesSearch && matchesGender && matchesDeceased;
  });

  // Export JSON file format
  const handleExport = () => {
    const jsonString = JSON.stringify(treeData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${treeData.name.toLowerCase().replace(/\s+/g, '_')}_family_tree.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Import JSON file
  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        
        // Simple structure validation
        if (parsed && typeof parsed === 'object' && Array.isArray(parsed.people)) {
          const validated: FamilyTreeData = {
            name: parsed.name || 'Imported Tree',
            description: parsed.description || 'Custom imported family tree.',
            people: parsed.people,
            marriages: Array.isArray(parsed.marriages) ? parsed.marriages : []
          };
          onImportTree(validated);
          e.target.value = '';
        } else {
          alert('Invalid file format. Ensure the JSON contains at least a "people" array.');
        }
      } catch (err) {
        alert('Failed to parse JSON file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <aside className="w-80 border-r border-[#2A2A28] bg-[#0D0D0D] flex flex-col h-full flex-shrink-0 text-[#E5E5E5]" id="sidebar-container">
      {/* App & Tree Header */}
      <div className="p-4 border-b border-[#2A2A28] bg-[#0A0A0A]">
        <div className="flex items-center gap-3.5 mb-3.5">
          {/* Logo element rotated 45 degrees */}
          <div className="w-10 h-10 border border-[#C5A059] flex items-center justify-center rotate-45 shrink-0" id="logo-icon">
            <span className="-rotate-45 text-[#C5A059] font-serif font-bold text-lg leading-none">H</span>
          </div>
          <div>
            <h1 className="text-sm font-serif font-light tracking-[0.2em] uppercase text-[#E5E5E5] leading-none" id="app-title">HARRISON ARCHIVE</h1>
            <span className="text-[9px] font-mono text-[#888] tracking-widest uppercase mt-1 block">Est. 1842 • Lineage Editor</span>
          </div>
        </div>
        
        {/* Tree data info section */}
        <div className="bg-[#161616] p-3 border border-[#2A2A28]">
          <h2 className="text-xs font-serif font-bold tracking-wider text-[#C5A059] line-clamp-1" id="tree-name">{treeData.name}</h2>
          <p className="text-[11px] text-[#888] line-clamp-2 mt-1 leading-relaxed font-sans">
            {treeData.description || 'No description provided.'}
          </p>
          <div className="flex items-center gap-4 mt-2.5 pt-2.5 border-t border-[#2A2A28] text-[9px] font-mono text-[#666] tracking-widest uppercase">
            <span id="people-count">👥 <strong>{treeData.people.length}</strong> members</span>
            <span id="marriages-count">💍 <strong>{treeData.marriages.length}</strong> marriages</span>
          </div>
        </div>
      </div>

      {/* Main Mode Tabs */}
      <div className="grid grid-cols-3 border-b border-[#2A2A28] p-1 bg-[#0A0A0A]" id="mode-tabs">
        <button
          id="btn-tab-tree"
          onClick={() => setActiveTab('tree')}
          className={`py-2 px-1 text-[10px] font-mono uppercase tracking-wider rounded-none flex flex-col items-center gap-1 transition-all cursor-pointer ${
            activeTab === 'tree' 
              ? 'bg-[#1A1A1A] text-[#C5A059] border border-[#2A2A28]' 
              : 'text-[#666] hover:text-[#AAA]'
          }`}
        >
          <Database size={14} className={activeTab === 'tree' ? 'text-[#C5A059]' : 'text-[#444]'} />
          <span>Tree</span>
        </button>
        <button
          id="btn-tab-timeline"
          onClick={() => setActiveTab('timeline')}
          className={`py-2 px-1 text-[10px] font-mono uppercase tracking-wider rounded-none flex flex-col items-center gap-1 transition-all cursor-pointer ${
            activeTab === 'timeline' 
              ? 'bg-[#1A1A1A] text-[#C5A059] border border-[#2A2A28]' 
              : 'text-[#666] hover:text-[#AAA]'
          }`}
        >
          <Calendar size={14} className={activeTab === 'timeline' ? 'text-[#C5A059]' : 'text-[#444]'} />
          <span>Timeline</span>
        </button>
        <button
          id="btn-tab-analytics"
          onClick={() => setActiveTab('analytics')}
          className={`py-2 px-1 text-[10px] font-mono uppercase tracking-wider rounded-none flex flex-col items-center gap-1 transition-all cursor-pointer ${
            activeTab === 'analytics' 
              ? 'bg-[#1A1A1A] text-[#C5A059] border border-[#2A2A28]' 
              : 'text-[#666] hover:text-[#AAA]'
          }`}
        >
          <BarChart2 size={14} className={activeTab === 'analytics' ? 'text-[#C5A059]' : 'text-[#444]'} />
          <span>Stats</span>
        </button>
      </div>

      {/* Secondary Sidebar Subtabs */}
      <div className="flex border-b border-[#2A2A28] text-[10px] font-mono uppercase tracking-widest text-[#666] bg-[#0E0E0E]" id="sidebar-subtabs">
        <button
          id="btn-subtab-people"
          onClick={() => setSubTab('people')}
          className={`flex-1 py-2.5 text-center border-b-2 font-medium transition-all cursor-pointer ${
            subTab === 'people' ? 'border-[#C5A059] text-[#C5A059]' : 'border-transparent hover:text-[#AAA]'
          }`}
        >
          Members ({filteredPeople.length})
        </button>
        <button
          id="btn-subtab-presets"
          onClick={() => setSubTab('presets')}
          className={`flex-1 py-2.5 text-center border-b-2 font-medium transition-all cursor-pointer ${
            subTab === 'presets' ? 'border-[#C5A059] text-[#C5A059]' : 'border-transparent hover:text-[#AAA]'
          }`}
        >
          Presets
        </button>
        <button
          id="btn-subtab-actions"
          onClick={() => setSubTab('import-export')}
          className={`flex-1 py-2.5 text-center border-b-2 font-medium transition-all cursor-pointer ${
            subTab === 'import-export' ? 'border-[#C5A059] text-[#C5A059]' : 'border-transparent hover:text-[#AAA]'
          }`}
        >
          Sync
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto bg-[#0D0D0D]" id="sidebar-subcontent">
        {subTab === 'people' && (
          <div className="p-4 space-y-4 flex flex-col h-full">
            {/* Quick Add Person */}
            <button
              id="sidebar-add-person-btn"
              onClick={onAddPerson}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-transparent hover:bg-[#C5A059] text-[#C5A059] hover:text-black font-serif border border-[#C5A059] text-xs uppercase tracking-widest transition-all cursor-pointer"
            >
              <Plus size={14} />
              Add Member
            </button>

            {/* Filter controls */}
            <div className="space-y-3 bg-[#111111] p-3 border border-[#2A2A28]">
              {/* SearchBar */}
              <div className="relative">
                <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#555]" />
                <input
                  id="search-people-input"
                  type="text"
                  placeholder="Search archive record..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-[#0A0A0A] border border-[#2A2A28] rounded-none text-xs text-[#E5E5E5] placeholder-[#555] focus:outline-none focus:border-[#C5A059] transition-all font-mono"
                />
              </div>

              {/* Advanced filter toggles */}
              <div className="grid grid-cols-2 gap-2 text-[10px] font-mono uppercase tracking-wider text-[#666]">
                <div>
                  <label className="block mb-1 text-[9px] text-[#555] tracking-widest">Gender</label>
                  <select
                    id="filter-gender-select"
                    value={genderFilter}
                    onChange={(e) => setGenderFilter(e.target.value as any)}
                    className="w-full bg-[#0A0A0A] border border-[#2A2A28] text-xs text-[#AAA] p-1 underline-offset-2 outline-none focus:border-[#C5A059] cursor-pointer"
                  >
                    <option value="all">All Genders</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block mb-1 text-[9px] text-[#555] tracking-widest">Status</label>
                  <select
                    id="filter-deceased-select"
                    value={deceasedFilter}
                    onChange={(e) => setDeceasedFilter(e.target.value as any)}
                    className="w-full bg-[#0A0A0A] border border-[#2A2A28] text-xs text-[#AAA] p-1 outline-none focus:border-[#C5A059] cursor-pointer"
                  >
                    <option value="all">Any Status</option>
                    <option value="living">Living</option>
                    <option value="deceased">Deceased</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Members list */}
            <div className="flex-1 space-y-1.5" id="members-list">
              {filteredPeople.length === 0 ? (
                <div className="py-8 text-center text-[#555] text-xs font-serif italic">
                  No records matched search.
                </div>
              ) : (
                filteredPeople.map(p => {
                  const years = p.birthDate 
                    ? `(${p.birthDate.split('-')[0]}${p.isDeceased ? ` – ${p.deathDate ? p.deathDate.split('-')[0] : '✝'}` : ''})` 
                    : '';
                  const isActive = activePerson?.id === p.id;
                  return (
                    <button
                      key={p.id}
                      id={`member-item-${p.id}`}
                      onClick={() => onSelectPerson(p)}
                      className={`w-full text-left p-2.5 flex items-center gap-3 transition-all border group cursor-pointer ${
                        isActive 
                          ? 'bg-[#161616] border-[#C5A059] shadow-[0_0_10px_rgba(197,160,89,0.15)] text-[#C5A059]' 
                          : 'bg-[#111111] hover:bg-[#161616] border-[#2A2A28] text-[#AAA] hover:text-[#E5E5E5]'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-none flex items-center justify-center font-bold text-xs shrink-0 border ${
                        isActive 
                          ? 'bg-[#C5A059] text-black border-[#C5A059]' 
                          : 'bg-[#1A1A1A] text-[#888] border-[#2A2A28] group-hover:border-[#444]'
                      }`}>
                        {p.firstName[0]}{p.lastName[0] || ''}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-baseline justify-between gap-1">
                          <p className={`text-xs font-serif font-bold tracking-wide truncate ${isActive ? 'text-[#C5A059]' : 'text-[#E5E5E5]'}`}>
                            {p.firstName} {p.lastName} {p.suffix && <span className="text-[10px] text-[#666]">{p.suffix}</span>}
                          </p>
                          {p.nickname && (
                            <span className="text-[10px] text-[#555] truncate max-w-[50px] italic font-serif">
                              "{p.nickname}"
                            </span>
                          )}
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-[#666] mt-0.5 font-mono">
                          <span className="truncate max-w-[120px]">{p.occupation || 'Archive Record'}</span>
                          <span>{years}</span>
                        </div>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        )}

        {subTab === 'presets' && (
          <div className="p-4 space-y-4">
            <div className="bg-[#111111] border border-[#C5A059]/30 p-3 text-[11px] leading-relaxed flex gap-2 text-[#AAA] font-serif italic text-center">
              <Sparkles size={16} className="shrink-0 text-[#C5A059] mt-0.5" />
              <span>Swiftly swap your active canvas workspace by loading historical presets below.</span>
            </div>
            
            <div className="space-y-3" id="presets-container">
              {PRELOADED_TREES.map(tree => (
                <button
                  key={tree.name}
                  id={`preset-card-${tree.name.toLowerCase().replace(/\s+/g, '-')}`}
                  style={{ contentVisibility: 'auto' }}
                  onClick={() => {
                    if (confirm(`Load "${tree.name}" family lineage? This will overwrite your active canvas.`)) {
                      onLoadTree(tree);
                    }
                  }}
                  className={`w-full text-left p-4 border transition-all cursor-pointer bg-[#111111] group hover:border-[#C5A059] ${
                    treeData.name === tree.name 
                      ? 'border-[#C5A059] ring-1 ring-[#C5A059]/25 bg-[#161616]' 
                      : 'border-[#2A2A28]'
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <h4 className={`text-xs font-serif font-bold tracking-wide ${treeData.name === tree.name ? 'text-[#C5A059]' : 'text-[#E5E5E5]'}`}>
                      {tree.name}
                    </h4>
                    {treeData.name === tree.name && (
                      <span className="text-[8px] bg-transparent border border-[#C5A059] text-[#C5A059] px-2 py-0.5 tracking-widest uppercase font-mono">LOADED</span>
                    )}
                  </div>
                  <p className="text-[11px] text-[#666] leading-relaxed group-hover:text-[#888] font-sans">
                    {tree.description}
                  </p>
                  <div className="flex gap-3 mt-3 pt-2.5 border-t border-[#2A2A28] text-[9px] font-mono text-[#555] uppercase tracking-widest font-semibold">
                    <span>👥 {tree.people.length} Members</span>
                    <span>💍 {tree.marriages.length} Marriages</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {subTab === 'import-export' && (
          <div className="p-4 space-y-4">
            <div className="space-y-2 bg-[#111111] p-3 border border-[#2A2A28]">
              <h3 className="text-xs font-serif font-bold tracking-wide text-[#C5A059]">Backup / Export</h3>
              <p className="text-[11px] text-[#666] leading-normal font-sans">
                Save your active genealogy canvas into a standardized JSON file.
              </p>
              <button
                id="export-tree-btn"
                onClick={handleExport}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 border border-[#2A2A28] bg-[#161616] hover:bg-[#202020] text-[#AAA] hover:text-[#E5E5E5] font-mono text-[10px] uppercase tracking-wider transition-all cursor-pointer"
              >
                <Download size={13} />
                Export JSON
              </button>
            </div>

            <div className="space-y-2 bg-[#111111] p-3 border border-[#2A2A28]">
              <h3 className="text-xs font-serif font-bold tracking-wide text-[#C5A059]">Restore / Import</h3>
              <p className="text-[11px] text-[#666] leading-normal font-sans">
                Load a previously backed-up archive JSON file.
              </p>
              <button
                id="import-tree-btn"
                onClick={handleImportClick}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 border border-[#C5A059] bg-[#C5A059]/5 hover:bg-[#C5A059]/10 text-[#C5A059] font-mono text-[10px] uppercase tracking-wider transition-all cursor-pointer"
              >
                <Upload size={13} />
                Select File
              </button>
              <input
                id="hidden-file-input"
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".json"
                className="hidden"
              />
            </div>

            <div className="space-y-2 bg-[#111111] p-3 border border-[#2A2A28]">
              <h3 className="text-xs font-serif font-bold tracking-wide text-red-400">Erase Archive</h3>
              <p className="text-[11px] text-[#666] leading-normal font-sans">
                Completely reset and format the workspace to start an empty state.
              </p>
              <button
                id="reset-canvas-btn"
                onClick={() => {
                  if (confirm("Are you sure you want to completely erase the current family tree? All unsaved work will be lost.")) {
                    onResetTree();
                  }
                }}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 border border-red-900/40 bg-red-950/20 hover:bg-red-900/20 text-red-400 font-mono text-[10px] uppercase tracking-wider transition-all cursor-pointer"
              >
                <Trash2 size={13} />
                Format Workspace
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Sidebar Footer */}
      <div className="p-3 bg-[#0A0A0A] border-t border-[#2A2A28] flex items-center justify-between text-[9px] text-[#444] font-mono uppercase tracking-widest shrink-0">
        <span>© 1842 Harrison Archive</span>
        <span className="flex items-center gap-1 text-[#C5A059]/50">
          <BookOpen size={10} /> LocalStorage Sync
        </span>
      </div>
    </aside>
  );
}
