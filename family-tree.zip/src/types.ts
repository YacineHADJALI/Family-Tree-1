/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Gender = 'male' | 'female' | 'nonbinary' | 'other';

export interface Person {
  id: string;
  firstName: string;
  lastName: string;
  maidenName?: string;
  suffix?: string;
  nickname?: string;
  gender: Gender;
  isDeceased: boolean;
  birthDate?: string;
  birthPlace?: string;
  deathDate?: string;
  deathPlace?: string;
  occupation?: string;
  biography?: string;
  avatarColor?: string; // Tailwind class
  fatherId?: string;
  motherId?: string;
}

export interface Marriage {
  id: string; // Unique marriage relation ID
  person1Id: string;
  person2Id: string;
  date?: string;
  place?: string;
  isDivorced?: boolean;
}

export interface FamilyTreeData {
  name: string;
  description: string;
  people: Person[];
  marriages: Marriage[];
}
